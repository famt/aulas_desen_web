
import './App.css';
import Alunos from "./components/Alunos"

function App() {
  return (
    <div className="App">
      <Alunos />
    </div>
  );
}

export default App;
